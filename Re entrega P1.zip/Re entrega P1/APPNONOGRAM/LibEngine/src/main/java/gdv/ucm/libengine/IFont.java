package gdv.ucm.libengine;

public interface IFont {
    int getSize();      // Obtener el tamaño de la fuente
    boolean isBold();   // Saber si la fuente es negrita
}