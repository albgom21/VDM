package gdv.ucm.libengine;

public interface ISound {
    void play();  // Reproducir sonido
    void stop();  // Parar sonido
}