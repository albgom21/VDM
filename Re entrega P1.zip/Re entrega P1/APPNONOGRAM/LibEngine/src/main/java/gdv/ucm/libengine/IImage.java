package gdv.ucm.libengine;

public interface IImage {
    int getWidth();  // Obtener el ancho de la imagen
    int getHeight(); // Obtener el alto de la imagen
}