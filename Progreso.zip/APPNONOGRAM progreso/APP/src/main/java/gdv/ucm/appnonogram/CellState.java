package gdv.ucm.appnonogram;

public enum CellState {
         GRAY, BLUE, WHITE, RED, NORENDER; // Estados de las celdas
}