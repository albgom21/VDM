package gdv.ucm.libenginepc;

import javax.sound.sampled.Clip;

import gdv.ucm.libengine.ISound;

public class SoundPC implements ISound {
    private Clip clip;
    SoundPC(Clip clip){
        this.clip = clip;
    }

    public Clip getClip(){return this.clip;}

    @Override
    public void play() {
        this.clip.start();
    }

    @Override
    public void stop() {
        if(this.clip.isRunning())
            this.clip.stop();
    }
}