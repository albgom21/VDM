package gdv.ucm.liblogica;

public enum CellState {
         GRAY, BLUE, WHITE, RED, NORENDER; // Estados de las celdas
}